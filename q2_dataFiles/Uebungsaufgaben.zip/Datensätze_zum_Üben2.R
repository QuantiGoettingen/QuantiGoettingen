###############################
### Datensaetze zum Ueben 2 ###
###############################

# Die folgenden Datensaetze koennen ueber Import Dataset oder read.csv geoeffnet werden

# Beispiel 1 fuer zweifaktorielle Varianzanalyse oder Kontrastanalyse
ChickFlick.txt
## Zielsetzung der fiktiven Studie: Herauszufinden wie sich verschiedene Arten von Filmen auf das arousal von Maennern und Frauen auswirken.
## Hypothese 1: Frauen und Maenner reagieren mit unterschiedlichem Arousal auf Liebesfilme und Thriller.
## Hypothese 2: Thriller fuehren zu hoeherem Arousal als Liebesfilme.
## Faktor 1 = gender(Male, Female)
## Faktor 2 = film(Bridget Jones Diary = Liebesfilm, Memento = Thriller) 
## Kriterium: arousal (kontinuierlich)

# Beispiel 2 fuer Regressionsanalyse mit Faktor und kontinuierlichem Praediktor
Elephant_Football.txt
## Zielsetzung der Studie: Herauszufinden, welches von 2 Teams besser ist, wenn die Erfahrung der eingesetzten Elefanten beruecksichtigt wird
## Hypothese: Team 1 ist besser als Team 2 auch wenn man f�r die Erfahrung der Elefanten kontrolliert.
## Pr�diktor 1 (Faktor) = elephant: Team (1 vs. 2)
## Praediktor 2: experience = Erfahrung des Elephanten 
## Kriterium: goals = kontinuierliche Variable

# Beispiel 3 fuer Varianz- und Regressionsanalyse
Schlafstoerungen.csv
## Hypothese 1: Negative Ereignisse, Temperatur und Stress haben einen Einfluss auf Schlafstoerungen
## Hypothese 2: Die negative Ereignisse wirken besonders stark bei Stress auf Schlafstoerungen.
## Hypothese 3: Niedrige Temperaturen reduzieren Schlafstoerungen
## Praediktor 1 = Neg_Ereignisse: Anzahl negativer Ereignisse
## Praediktor 2 = Temperatur: Mittlere Au�entemperatur im Untersuchungszeitraum
## Praediktor 3 = Stress: Wert in einem Stressfragebogen (hohe Werte bedeuten viel Stress)
## Kriterium = Schlafstoerungen: Anzahl der Tage an denen Schlafstoerungen berichtet wurden
## Hinweis zur Analyse: Die ersten beiden Hypothesen lassen sich mit Modellvergleichen am besten beantworten.

# Beispiel 4 fuer Kontrastanalyse
FruitflyDataReduced.csv
## Zielsetzung der realen Studie: Herauszufinden ob Paarung sich negativ auf die Lebensdauer bei maennlichen Fruchtfliegen auswirkt
## Hypothese: Haeufiges Paaren reduziert die Lebensdauer
## Praediktor (Faktor mit 5 Auspraegungen) = CompanionNumber: 
##            (Pregnant8 = 8 bereits befruchtete Weibchen werden zu einem Maennchen gegeben
##            (Pregnant1 = 1 befruchtetes Weibchen wird zu einem Maennchen gegeben)
##            (None0 = kein Weibchen wird hinzugegeben)
##            (Virgin1 = 1 nicht befruchtetes Weibchen wird hinzugegeben)
##            (Virgin8 = 8 nicht befruchtete Weibchen werden hinzugegeben)
## Kriterium: Longevity (Lebensdauer des Maennchen in Tagen)
## Hinweis zur Analyse: Ueberlegen Sie zuerst mit welchem Kontrast Sie die Hypothese testen koennen. 
## Hinweis 2: Die deskriptiven Ergebnisse sind hilreich anzusehen.

## Beispiel 5 fuer Bestimmung des besten Modells
ScholasticAptitudeTest
## Zielsetzung der Studie: Herauszufinden, welche Variablen die Leistung von amerikanischen Schuelern beim Scholastic Aptitude Test (SAT) vorhersagen.
## Es gibt Daten aus den 50 Bundestaaten der USA
## Hypothesen: Keine. Es soll ermittelt werden, was die Praediktoren sind.
## Praediktor 1 = Spend: Dollar pro Schueler pro Jahr
## Praediktor 2 = StuTeaRat: Student Teacher Ratio: Anzahl der Schueler pro Lehrer
## Praediktor 3 = Salary: Mittleres Einkommen der Lehrer
## Praediktor 4 = PrcntTake: Anteil der Schueler, die am Test teilnehmen (darf die Schulbehoerde festlegen)
## Kriterium 1 = SATV: Wert im verbalen Teil des SAT
## Kriterium 2 = SATM: Wert im mathematischen Teil des SAT
## Kriterium 3 = SATT: Totaler Wert im SAT
## Hinweis 1: Nutzen Sie den SATT fuer die Analyse
## Hinweis 2: Nehmen Sie Modellvergleiche, um das beste Modell herauszufinden

# Beispiel 5 fuer Regressionsanalyse mit Faktoren
Salary.csv
## Zielsetzung der Studie: Herauszufinden wie die verschiedenen Stufen von Professoren an einer amerikanischen Universitaet bezahlt werden
## Erklaerung: Es gibt Assistenzprofessoren, Associate Professors und Full Professors
## Hypothese 1: Full professors werden besser als associate und associate besser als assistant professors bezahlt
## Hypothese 2: Die Bezahlung unterscheidet sich zwischen den Fachbereichen
## Praediktor 1 (Faktor) = Org: Fachbereich (wird in OrgName erlaeutert)
## Praediktor 2 (Faktor) = Position: Stufe der Professur (Assistant, Associate, Full)
## Kriterium = Salary: Jahreseinkommen in Dollar
## Challenge: Testen Sie zusaetzlich Hypothese 3: Die verschiedenen Professorstufen werden je nach Fachbereich unterschiedlich bezahlt
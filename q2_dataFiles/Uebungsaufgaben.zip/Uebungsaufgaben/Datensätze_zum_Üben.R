###################################
### Datensaetze aus R zum Ueben ###
###################################
# Website mit Uebersicht
# https://stat.ethz.ch/R-manual/R-devel/library/datasets/html/00Index.html

# Beispiel 1 fuer einfaktorielle Varianzanalyse
InsectSprays
## Hypothese: Verschiedene Insektensprays sind unterschiedlich wirksam zur Reduktion der Anzahl von Insekten auf der Haut.
## UV = Faktor: spray
## AV = Count-Variable: count Anzahl der Insekten bei Verwendung des jeweiligen Sprays
## Hinweis: Man koennte auch mal Kontraste rechnen, um zu sehen, ob die wirksamen Sprays unterschiedlich wirksam sind

# Beispiel 2 fuer Trendanalyse oder zweifaktorielle Varianzanalyse
ToothGrowth
## Hypothese: Eine hoehere Gabe von Vitamin C verbessert das Zahnwachstum bei Meerschweinchen mehr als eine niedrige Gabe.
## Kriterium = kontinuierliche Variable: len = Zahnlaenge
## Praediktoren = Faktoren: 1. dose = Dosis , 2. supp = Art wie das Vitamin C verabreicht wurde. 
## Hinweis: Eine Trendanalyse fuer den Faktor dose waere angemessen. Fuer diesen muesste daher
## ein polynomialer Kontrast definiert werden.

# Beispiel 3 fuer Regressionsanalyse
mtcars
## Hypothese: Die unten genannten 5 Faktoren und Variablen beeinflussen wie effizient 
### ein Fahrzeug Kraftstoff verwendet.
## Kriterium = kontinuierliche Variable: mpg = miles per gallon
## Praediktoren
### Faktoren
# cyl 	Number of cylinders
# am 	  Transmission (0 = automatic, 1 = manual)
# gear  Number of forward gears
### kontinuierliche Variablen
# hp  horsepower
# wt 	Weight (1000 lbs)

# Um Datensaetze anzuzeigen bitte den Befehl View nutzen
View(mtcars)
# Damit Datensaetze im Global Environment erscheinen folgenden Befehl nutzen
mtcars <- as.data.frame(mtcars)
# Nun kann mit dem Commander gearbeitet werden. Viel Spass!
